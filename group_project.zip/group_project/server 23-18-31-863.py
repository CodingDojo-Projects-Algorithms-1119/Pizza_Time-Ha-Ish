from flask import Flask, render_template, redirect, request, flash, session
from mysqlconnection import connectToMySQL
from flask_bcrypt import Bcrypt
from datetime import datetime
import re

app = Flask(__name__, static_url_path='/static')
app = Flask(__name__)
app.secret_key = ('pikachu')
bcrypt = Bcrypt(app)
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$') 

@app.route('/')
def index():
    return render_template('register.html')

@app.route('/register', methods=["POST"])
def user_register():
    is_valid = True
    if len(request.form['fn']) < 2:
        is_valid = False
        flash('First name must be at least 2 characters.')
    if len(request.form['ln']) < 2:
        is_valid = False
        flash('Last name must be at least 2 characters.')
    if not EMAIL_REGEX.match(request.form['em']):
        is_valid = False
        flash('Please enter valid email.')
    mysql = connectToMySQL('pizza_time')
    query = 'SELECT * FROM users WHERE email=%(e_m)s;'
    data = {'e_m': request.form['em']}
    user = mysql.query_db(query,data)
    if user:
        is_valid = False
        flash('Email is already exist. Please choose another email.')
    if len(request.form['ad']) < 1:
        is_valid = False
        flash('Please enter address.')
    if len(request.form['ct']) < 1:
        is_valid = False
        flash('Please enter city.')
    if len(request.form['st']) < 1:
        is_valid = False
        flash('Please enter state.')
    if len(request.form['pw']) < 8:
        is_valid = False
        flash('Password must be at least 8 characters.')
    if request.form['c_pw'] != request.form['pw']:
        is_valid = False
        flash('Passwords must match.')
    if not is_valid:
        return redirect('/')
    else:
        encrypted_pw = bcrypt.generate_password_hash(request.form['pw'])
        mysql = connectToMySQL('pizza_time')
        query = "INSERT INTO users(first_name, last_name, address, city, state, email, password, created_at, updated_at) VALUES(%(f_n)s, %(l_n)s, %(a_d)s, %(c_t)s, %(s_t)s, %(e_m)s, %(p_w)s, NOW(), NOW());"
        data = {
            'f_n': request.form['fn'],
            'l_n': request.form['ln'],
            'e_m': request.form['em'],
            'a_d': request.form['ad'],
            'c_t': request.form['ct'],
            's_t': request.form['st'],
            'p_w': encrypted_pw
        }
        user_id = mysql.query_db(query, data)
        session['user_id'] = user_id
        return render_template('order.html')

@app.route('/add_to_order', methods=["POST"])
def add_to_order():
    price = 7.99
    topping = ""
    if request.form.get('Pepperoni'):
        if len(topping):
            topping = topping + ", " + request.form['Pepperoni']
        else:
            topping = topping + request.form['Pepperoni']
        price = price + 1.99
    if request.form.get('Italian Sausage'):
        if len(topping):
            topping = topping + ", " + request.form['Italian Sausage']
        else:
            topping = topping + request.form['Italian Sausage']
        price = price + 1.99
    if request.form.get('Meatball'):
        if len(topping):
            topping = topping + ", " + request.form['Meatball']
        else:
            topping = topping + request.form['Meatball']
        price = price + 1.99
    if request.form.get('Ham'):
        if len(topping):
            topping = topping + ", " + request.form['Ham']
        else:
            topping = topping + request.form['Ham']
        price = price + 1.99
    if request.form.get('Grilled Chicken'):
        if len(topping):
            topping = topping + ", " + request.form['Grilled Chicken']
        else:
            topping = topping + request.form['Grilled Chicken']
        price = price + 1.99
    if request.form.get('Beef'):
        if len(topping):
            topping = topping + ", " + request.form['Beef']
        else:
            topping = topping + request.form['Beef']
        price = price + 1.99
    if request.form.get('Pork'):
        if len(topping):
            topping = topping + ", " + request.form['Pork']
        else:
            topping = topping + request.form['Pork']
        price = price + 1.99
    if request.form.get('Mushrooms'):
        if len(topping):
            topping = topping + ", " + request.form['Mushrooms']
        else:
            topping = topping + request.form['Mushrooms']
        price = price + 0.99
    if request.form.get('Roasted Spinach'):
        if len(topping):
            topping = topping + ", " + request.form['Roasted Spinach']
        else:
            topping = topping + request.form['Roasted Spinach']
        price = price + 0.99
    if request.form.get('Red Onions'):
        if len(topping):
            topping = topping + ", " + request.form['Red Onions']
        else:
            topping = topping + request.form['Red Onions']
        price = price + 0.99
    if request.form.get('Mediterranean Black Olives'):
        if len(topping):
            topping = topping + ", " + request.form['Mediterranean Black Olives']
        else:
            topping = topping + request.form['Mediterranean Black Olives']
        price = price + 0.99
    if request.form.get('Green Bell Peppers'):
        if len(topping):
            topping = topping + ", " + request.form['Green Bell Peppers']
        else:
            topping = topping + request.form['Green Bell Peppers']
        price = price + 0.99
    if request.form.get('Banana Peppers'):
        if len(topping):
            topping = topping + ", " + request.form['Banana Peppers']
        else:
            topping = topping + request.form['Banana Peppers']
        price = price + 0.99
    if request.form.get('Pineapple'):
        if len(topping):
            topping = topping + ", " + request.form['Pineapple']
        else:
            topping = topping + request.form['Pineapple']
        price = price + 0.99
    if request.form.get('Jalapeño Peppers'):
        if len(topping):
            topping = topping + ", " + request.form['Jalapeño Peppers']
        else:
            topping = topping + request.form['Jalapeño Peppers']
        price = price + 0.99
    if request.form.get('Roma Tomatoes'):
        if len(topping):
            topping = topping + ", " + request.form['Roma Tomatoes']
        else:
            topping = topping + request.form['Roma Tomatoes']
        price = price + 0.99
    
    price = price + price*0.075
    mysql = connectToMySQL('pizza_time')
    query = 'INSERT INTO orders(user_id, qty, method, size, crust, price, topping, fave, created_at, updated_at) VALUES(%(user_id)s, %(qty)s, %(method)s, %(size)s, %(crust)s, %(price)s, %(topping)s, 0, NOW(), NOW());'
    data = {
        'user_id': session['user_id'],
        'qty': request.form['qty'],
        'method': request.form['method'],
        'size': request.form['size'],
        'crust': request.form['crust'],
        'price': price,
        'topping': topping
    }
    order_id = mysql.query_db(query,data)
    return render_template('purchase.html')
    
@app.route('/to_login')
def login():
    return render_template('login.html')

@app.route('/new_order')
def pizza():
    return render_template('pizza.html')

@app.route('/to_register')
def register():
    return render_template('register.html')

@app.route('/login', methods = ['POST'])
def user_login():
    is_valid = True
    if not request.form['em']:
        is_valid = False
        flash('Please enter an email.')
    if not EMAIL_REGEX.match(request.form['em']):
        is_valid = False
        flash('Please enter a valid email.')
    if not is_valid:
        return render_template('login.html')
    else:
        mysql = connectToMySQL('pizza_time')
        query = 'SELECT * FROM users WHERE users.email = %(e_m)s;'
        data = {'e_m' : request.form['em']}
        user_info = mysql.query_db(query, data)
        if user_info:
            if not request.form['pw']:
                is_valid = False
                flash('Please enter the password.')
            elif not bcrypt.check_password_hash(user_info[0]['password'], request.form['pw']):
                is_valid = False
                flash('Password is not valid.')
            if is_valid:
                session['user_id']=user_info[0]['id']
                return render_template('order.html')
            else:
                return render_template('login.html')
        else:
            flash('please enter a valid email address.')
            return render_template('login.html')

@app.route('/logout')
def user_logout():
    session.clear()
    return redirect('/')

@app.route('/home')
def home():
    return render_template('order.html')

@app.route('/order')
def user_order():
    return render_template('purchase.html')

@app.route('/account')
def user_account():
    mysql = connectToMySQL('pizza_time')
    query = 'SELECT * FROM orders WHERE user_id = %(user_id)s;'
    data = {'user_id': session['user_id']}
    user_orders = mysql.query_db(query, data)
    mysql = connectToMySQL('pizza_time')
    query = 'SELECT * FROM users WHERE id = %(user_id)s;'
    data = {'user_id': session['user_id']}
    users = mysql.query_db(query, data)
    return render_template('account.html', user_orders=user_orders, user=users[0])

@app.route('/update', methods = ['POST'])
def update():
    mysql = connectToMySQL('pizza_time')
    query = 'UPDATE users SET first_name = %(fn)s, last_name = %(ln)s, email = %(em)s, address = %(ad)s, city = %(ct)s, state = %(st)s WHERE id = %(user_id)s;'
    data = {
        'user_id': session['user_id'],
        'fn': request.form['fn'],
        'ln': request.form['ln'],
        'em': request.form['em'],
        'ad': request.form['ad'],
        'ct': request.form['ct'],
        'st': request.form['st']
    }
    mysql.query_db(query, data)
    if request.form.get('favorite'):
        mysql = connectToMySQL('pizza_time')
        query = 'SELECT id FROM orders WHERE user_id = %(user_id)s AND size = %(size)s AND topping = %(topping)s;'
        data = {
            'user_id': session['user_id'],
            'size': request.form['size'],
            'topping': request.form['topping']
        }
        id = mysql.query_db(query, data)
    
        mysql = connectToMySQL('pizza_time')
        query = 'UPDATE orders SET fave = 1 WHERE user_id = %(user_id)s AND id = %(id)s;'
        data = {
            'user_id': session['user_id'],
            'id': id[0]
        }
        mysql.query_db(query, data)
    return redirect('/account')

if __name__ == '__main__':
    app.run(debug=True)